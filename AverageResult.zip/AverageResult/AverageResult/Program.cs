﻿using System;

namespace AverageResult
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("You will find three numbers to find the average.\n");

            double a = 0, b = 0, c = 0;


            Console.WriteLine("Please enter your first number:");
            a = double.Parse(Console.ReadLine());

            Console.WriteLine("Please enter your second number:");
            b = double.Parse(Console.ReadLine());

            Console.WriteLine("Please enter your third number:");
            c = double.Parse(Console.ReadLine());


            double sum = a + b + c;
            double average = (sum / 3);
            Console.WriteLine($"The sum of your numbers is {sum}\n");
            Console.WriteLine($"The average of your numbers resulted in: {average}, therefore you have...\n ");

            if (average >= 10)
            {
                Console.WriteLine("passed!");
            }
            else
            {
                Console.WriteLine("failed!");
            }


        }
    }
}
