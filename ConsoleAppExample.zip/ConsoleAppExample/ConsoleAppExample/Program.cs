﻿using System;

namespace ConsoleAppExample
{
    class Program
    {
        static void Main(string[] args)
        {
            /// here I am recalling the second method called HelloWorld() to print to screen 
            string message = HelloWorld();
            Console.WriteLine(message);
            Console.ReadLine();
        }

        static string HelloWorld() 
        {
            return "Hello World!";
        }
        /// static string HelloWorld() => "Hello World!" 
        /// - this is a ladba that will avoid the use of {} and the retun keyword 
    }
}
