﻿using System;

namespace AvgNonSpecNumOfTest2
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;

            Console.WriteLine("Please enter a valid number between 0 and 100\n" +
                "Enter values like the following example: \n\n" +
                "Example: (100 100 90)\n" +
                "After the last number is inputted, press enter.");

            string scores = Console.ReadLine();

            string[] scoresArray = scores.Split(' ');
            int[] ints = Array.ConvertAll(scoresArray, s => int.Parse(s));
            

            for (int i = 0; i < ints.Length; i++)
            {
                    sum += ints[i];
            }
            
            int avg = sum / ints.Length;
            if (avg > 90)
            {
                Console.WriteLine($"{avg}% A!");
            }
            else if (avg < 89.99d && avg > 80)
            {
                Console.WriteLine($"{avg}% B.");
            }
            else if (avg < 79.99d && avg > 70)
            {
                Console.WriteLine($"{avg}% C...");
            }
            else if (avg < 69.99d && avg > 60)
            {
                Console.WriteLine($"{avg}% D >:(");
            }
            else { Console.WriteLine($"{avg}% F... for FAILER!"); }
        }

    }
}
