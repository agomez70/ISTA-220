﻿using System;

namespace CalculatingAvgs
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, sum = 0;

            Console.WriteLine("You have been chosen to sum up ten numbers!\n");
            Console.WriteLine("Please enter values 0-100 before you break my application...\n");
            Console.WriteLine("Enter your ten numbers below:\n");

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"Number {i}/10:");
                n = int.Parse(Console.ReadLine());
                while (n < 0 || n > 100)
                {
                    Console.WriteLine("Invalid number. Please enter numbers 0 to 100.");
                    n = int.Parse(Console.ReadLine());
                }
                    sum += n;
            }
            Console.WriteLine($"The sum of your numbers is: {sum}");


        }
    }
}
