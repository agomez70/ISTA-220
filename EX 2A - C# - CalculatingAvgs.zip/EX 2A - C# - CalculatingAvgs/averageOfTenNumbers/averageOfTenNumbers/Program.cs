﻿using System;

namespace averageOfTenNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            double n, sum = 0;
            double avg = 0.0d;

            Console.WriteLine("Please enter your last ten grades to find out your grade.\n" +
                "Remeber that the scores can only be from 0 to 100!");

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"Assignment {i}/10");
                n = double.Parse(Console.ReadLine());
                while (n < 0 || n > 100)
                {
                    Console.WriteLine("Invalid number. Please enter numbers 0 to 100.");
                    n = double.Parse(Console.ReadLine());
                }
                sum += n;
            }
            avg = sum / 10;
            Console.WriteLine("");

            if (avg > 90)
            {
                Console.WriteLine($"{avg}% A!");
            }
            else if (avg < 89.99d && avg > 80)
            {
                Console.WriteLine($"{avg}% B.");
            }
            else if (avg < 79.99d && avg > 70)
            {
                Console.WriteLine($"{avg}% C...");
            }
            else if (avg < 69.99d && avg > 60)
            {
                Console.WriteLine($"{avg}% D >:(");
            }
            else { Console.WriteLine($"{avg}% F... for FAILER!"); }

        }
    }
}
