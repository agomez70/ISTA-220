﻿using System;

namespace AvgSpecificNumOfTest
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, avg, sum = 0;

            Console.WriteLine("Please enter the amount of test graded below");
            a = double.Parse(Console.ReadLine());
            for (int i = 1; i <= a; i++)
            {
                Console.WriteLine($"Grade for Test {i}/{a}: ");
                b = double.Parse(Console.ReadLine());
                while (b < 0 || b > 100)
                {
                    Console.WriteLine("Invalid number. Please enter numbers 0 to 100.");
                    b = int.Parse(Console.ReadLine());
                }
                sum += b;
            }
            avg = sum / a;
            Console.WriteLine("");

            if (avg > 90)
            {
                Console.WriteLine($"{avg}% A!");
            }
            else if (avg < 89.99d && avg > 80)
            {
                Console.WriteLine($"{avg}% B.");
            }
            else if (avg < 79.99d && avg > 70)
            {
                Console.WriteLine($"{avg}% C...");
            }
            else if (avg < 69.99d && avg > 60)
            {
                Console.WriteLine($"{avg}% D >:(");
            }
            else { Console.WriteLine($"{avg}% F... for FAILER!"); }
        }
    }
}
