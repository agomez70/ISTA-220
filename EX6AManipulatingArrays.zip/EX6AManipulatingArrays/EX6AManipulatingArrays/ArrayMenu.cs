﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace EX6AManipulatingArrays
{
    class ArrayMenu
    {
        public static void first()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"First Array!\n");
            Console.WriteLine("------------\n");
            Console.ResetColor();
            
        }
        public static void second()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Second Array!\n");
            Console.WriteLine("-------------\n");
            Console.ResetColor();
            
        }
        public static void third()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Third Array!\n");
            Console.WriteLine("------------\n");
            Console.ResetColor();
            
        }
        public static void firstProblem()
        {
            ForegroundColor = ConsoleColor.Green;
            WriteLine("Counting, Summing, and Computing the mean!");
            WriteLine("------------------------------------------\n");
            ResetColor();
        }
        public static void secondProblem()
        {
            ForegroundColor = ConsoleColor.Green;
            WriteLine("Reversing Arrays!");
            WriteLine("-----------------\n");
            ResetColor();
        }
        public static void thirdProblem()
        {
            ForegroundColor = ConsoleColor.Green;
            WriteLine("Rotating Arrays!");
            WriteLine("----------------\n");
            ResetColor();
        }
        public static void fourthProblem()
        {
            ForegroundColor = ConsoleColor.Green;
            WriteLine("Sorting Arrays!");
            WriteLine("---------------\n");
            ResetColor();
        }

    }
}
