﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EX6AManipulatingArrays
{
    public class CountSumAvg
    {
        //Method to count, sum and avg
        public static void CountAndSumArray(int[] array)
        {

            // Gets the total number of elements 
            Console.WriteLine($"Total number of elements in this " +
                $"array: {array.Length}");


            // Sums up the elements of the array
            int sum = 0;
            foreach (int arrayA in array)
            {
                sum += arrayA;
            }
            Console.WriteLine($"The sum of these elements is: {sum}");


            // Gets the average using the count and sum 
            double avg = (double)sum / (double)array.Length;
            Console.WriteLine($"The average of this array is: {avg}\n");

        }
        //Printing to Main()
        public static void firstArrayCSA()
        {
            ArrayMenu.first();
            int[] ArrayA = { 0, 2, 4, 6, 8, 10 };
            CountAndSumArray(ArrayA);
        }
        public static void secondArrayCSA()
        {
            ArrayMenu.second();
            int[] ArrayB = { 1, 3, 5, 7, 9 };
            CountAndSumArray(ArrayB);
        }
        public static void thirdArrayCSA()
        {
            ArrayMenu.third();
            int[] ArrayC = { 3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 9 };
            CountAndSumArray(ArrayC);
        }
    }
    
}
