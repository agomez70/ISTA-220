﻿using System;
using static System.Console;



namespace EX6AManipulatingArrays
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayMenu.firstProblem();

            CountSumAvg.firstArrayCSA();
            CountSumAvg.secondArrayCSA();
            CountSumAvg.thirdArrayCSA();

            ReadLine();
            Clear();

            ArrayMenu.secondProblem();

            Reversing.firstRevArray();
            Reversing.secondRevArray();
            Reversing.thirdRevArray();

            ReadLine();
            Clear();

            ArrayMenu.thirdProblem();

            RotatingArrays.firstRotArray();
            RotatingArrays.secondRotArray();
            RotatingArrays.thirdRotArray();

            ReadLine();
            Clear();

            ArrayMenu.fourthProblem();

            SortingArray.RunArray();
        }
    }
}
