﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EX6AManipulatingArrays
{
    public class Reversing
    {
        //Reverse method
        public static void ReverseArray(int[] array)
        {
            int length = array.Length - 1;
            string strReverse = null;
            while (length >= 0)
            {
                strReverse += array[length] + " ";
                length--;
            }
            Console.WriteLine($"The reverse order of this array is: {strReverse}\n");
        }
        //Printing to Main()
        public static void firstRevArray()
        {
            ArrayMenu.first();
            int[] ArrayA = { 0, 2, 4, 6, 8, 10 };
            ReverseArray(ArrayA);
        }
        public static void secondRevArray()
        {
            ArrayMenu.second();
            int[] ArrayB = { 1, 3, 5, 7, 9 };
            ReverseArray(ArrayB);
        }
        public static void thirdRevArray()
        {
            ArrayMenu.third();
            int[] ArrayC = { 3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 9 };
            ReverseArray(ArrayC);
        }
    }
}
