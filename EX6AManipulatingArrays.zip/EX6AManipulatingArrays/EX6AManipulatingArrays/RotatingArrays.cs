﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX6AManipulatingArrays
{
    class RotatingArrays
    {
        //rotating to the left 
        public static void leftRotatingArray(int[] array, int direction, int number)
        {
            for (int i = 0; i < direction; i++)
            {
                leftRotateByOne(array, number);
            }
            Console.WriteLine($"This array is being rotated {direction} number to the left!");
        }
        public static void leftRotateByOne(int[] array, int number)
        {

            int temp = array[0];
            for (int i = 0; i < array.Length - 1; i++)
            {
                array[i] = array[i + 1];
            }
            array[array.Length - 1] = temp;
        }
        public static void printRotateArray(int[] array, int size)
        {

            for (int i = 0; i < size; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine();
        }

        //rotating to the right 
        public static void rightRotatingArray(int[] array, int direction, int number)
        {
            for (int i = 0; i < direction; i++)
            {
                rightRotateByOne(array, number);
            }
            Console.WriteLine($"This array is being rotated {direction} number to the right!");
        }
        public static void rightRotateByOne(int[] array, int number)
        {

            int temp; 
            for (int i = 0; i < array.Length - 1; i++)
            {
                temp = array[0];
                array[0] = array[i + 1];
                array[i + 1] = temp;
            }
           
        }
        public static void printRotateRightArray(int[] array, int size)
        {
            for (int i = 0; i < size; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine("\n");
        }

        //Printing to Main()
        public static void firstRotArray()
        {
            ArrayMenu.first();
            int[] ArrayA = { 0, 2, 4, 6, 8, 10 };
            leftRotatingArray(ArrayA, 2, 6);
            printRotateArray(ArrayA, 6);

            rightRotatingArray(ArrayA, 4, 6);
            printRotateRightArray(ArrayA, 6);
        }
        public static void secondRotArray()
        {
            ArrayMenu.second();
            int[] ArrayB = { 1, 3, 5, 7, 9 };
            leftRotatingArray(ArrayB, 3, 5);
            printRotateArray(ArrayB, 5);

            rightRotatingArray(ArrayB, 6, 5);
            printRotateRightArray(ArrayB, 5);
        }
        public static void thirdRotArray()
        {
            ArrayMenu.third();
            int[] ArrayC = { 3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 9 };
            leftRotatingArray(ArrayC, 5, 12);
            printRotateArray(ArrayC, 12);

            rightRotatingArray(ArrayC, 10, 12);
            printRotateRightArray(ArrayC, 12);
        }
    }
}
