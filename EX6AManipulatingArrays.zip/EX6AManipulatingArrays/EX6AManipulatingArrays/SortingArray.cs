﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX6AManipulatingArrays
{
    class SortingArray
    {
        //Method to sort arrays 
        public static void SortArrayC(int[] Array)
        {
            int length = Array.Length;
            for (int i = 0; i < length - 1; i++)
            {
                for (int j = 0; j < length - i - 1; j++)
                {
                    if (Array[j] > Array[j + 1])
                    {
                        int temp = Array[j];
                        Array[j] = Array[j + 1];
                        Array[j + 1] = temp;
                    }
                }
            }
        }
        //prints array
        public static int[] printArrayC(int[] array)
        {

            int length = array.Length;
            for (int i = 0; i < length; i++)
            {
                Console.Write(array[i] + " ");
            }
            return array;
        }
        //runs it on Main()
        public static void RunArray()
        {
            int[] ArrayC = { 3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 9 };
            SortArrayC(ArrayC);
            ArrayMenu.third();
            Console.Write("This is your sorted array: ");
            printArrayC(ArrayC);
            Console.ReadLine();
        }
    }
}
