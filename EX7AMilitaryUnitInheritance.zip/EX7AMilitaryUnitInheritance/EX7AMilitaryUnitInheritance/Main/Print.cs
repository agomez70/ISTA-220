﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    public class Print
    {
        public static void Personnel()
        {
            Titles.BaseTitle("Personnel in my Military Unit");

            Titles.DerivedTitle("Junior Enlisted Warriors");

            Junior junior = new Junior();
            junior.Rank("Private, Private First Class, Lance Corporal.\n");
            junior.MOS("Every Marine has a job. For example, when I " +
                "was a Junior Marine,\n\tmy job title was Transmissions Systems" +
                " Operator.\n");
            junior.ProCon();

            Console.ReadLine();

            Titles.DerivedTitle("Non-Commissioned Officers");

            NCOs nco = new NCOs();
            nco.Rank("Corporal, Sergeant.\n");
            nco.MOS("Job title's for NCO's vary in regards to " +
                "their performance.\n\tSome NCO's stick with their original " +
                "title like Transmissions Systems Operator. \n\tOther's may " +
                "receive a higher billet that will describe them as a " +
                "supervisor\n\tor chief of some sort.\n");
            nco.ProCon();
            nco.FitReps();

            Console.ReadLine();

            Titles.DerivedTitle("Staff Non-Commissioned Officers");

            SNCOs snco = new SNCOs();
            snco.Rank("Staff Sergeant, Gunnery Sergeant, Master Sergeant,\n\t" +
                "First Sergeant, Master Gunnery Sergeant, Sergeant Major.\n");
            snco.MOS("A SNCO generally get their jobs title change all " +
                "together.\n\tFor example, as a Junior Marine and NCO with the job " +
                "title\n\t'Transmissions Systems Operator' (0621), a SNCO will this " +
                "title will become a \n\t'Transmissions Chief' (0629). " +
                "A Master Sergeant and Master Gunnery Sergeant \n\tare Subject " +
                "Matter Experts in their jobs, while First Sergeant and Sergeant " +
                "Majors \n\twill become the senior enlisted advisors for Commanders.\n");
            snco.FitReps();

            Console.ReadLine();
            Console.Clear();
        }
        public static void Vehicles()
        {
            Titles.BaseTitle("Vehicles in my Military Unit");

            Titles.DerivedTitle("High Mobility Multipurpose Wheeled Vehicle");

            HMMWV humvee = new HMMWV();
            humvee.TroopCapacity(8);
            humvee.Loudness(false);
            humvee.Accelerating();
            humvee.Braking();
            humvee.Drive();

            Console.ReadLine();

            Titles.DerivedTitle("Assault Amphibious Vehicle");

            AAV aav = new AAV();
            aav.TroopCapacity(16);
            aav.Loudness(true);
            aav.Diving();
            aav.Danger();
            aav.Drive();

            Console.ReadLine();
            Console.Clear();
        }
        public static void Weapons()
        {
            Titles.BaseTitle("Weapons in my Military Unit");

            Titles.DerivedTitle("M-16A4 Service Rifle");

            M16 m16 = new M16();
            m16.AmmoType("5.56x45mm NATO");
            m16.Range(3600);
            m16.Size();
            m16.Requirement();

            Console.ReadLine();

            Titles.DerivedTitle("M240 Light-Machine Gun");

            M240 m240 = new M240();
            m240.AmmoType("7.62x51mm NATO");
            m240.Range(3725);
            m240.Size();
            m240.NonRequirement();

            Console.ReadLine();
        }
    }

}
