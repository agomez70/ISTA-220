﻿using System;

namespace EX7AMilitaryUnitInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Print.Personnel();
            Print.Vehicles();
            Print.Weapons();
        }

    }
}
