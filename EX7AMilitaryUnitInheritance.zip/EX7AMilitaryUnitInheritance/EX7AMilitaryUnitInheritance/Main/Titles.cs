﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class Titles
    {
        public static void BaseTitle(string title)
        {
            Console.SetCursorPosition(Console.WindowWidth / 2, Console.CursorTop);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($"{title}...\n");
            Console.ReadLine();
            Console.ResetColor();
        }
        public static void DerivedTitle(string title)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write($"\t{title}\n");
            Console.ReadLine();
            Console.ResetColor();
        }
    }
}
