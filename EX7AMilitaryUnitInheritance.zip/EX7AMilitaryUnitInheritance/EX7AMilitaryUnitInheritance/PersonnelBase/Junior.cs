﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class Junior : Personnel
    {
        public void ProCon()
        {
            Console.WriteLine("\tJunior Marines get evaluated on a monthly " +
                "basis by their direct supervisor. \n\tThey receive Proficiency " +
                "and Conduct Marks that detail their overall performance " +
                "as a Marine.\n");
        }
    }
}
