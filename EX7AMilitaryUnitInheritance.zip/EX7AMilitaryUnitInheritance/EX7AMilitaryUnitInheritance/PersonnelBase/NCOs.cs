﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class NCOs : Personnel
    {
        public void ProCon()
        {
            Console.WriteLine("\tNon-Commissioned Officers get evaluated on a monthly " +
              "basis by their direct supervisor.\n\tThey receive Proficiency" +
              "and Conduct Marks that detail their overall\n\tperformance " +
              "as a Marine only if they are a Corporal.\n");
        }
        public void FitReps()
        {
            Console.WriteLine("\tThe other type of Non-Commissioned Officers " +
                "are Sergeants. Sergeants get evaluated yearly.\n\tIt is the " +
                "Sergeants responsibily to write a Fitness Report that " +
                "details \n\tall of their accomplishments. This document gets " +
                "reviewed by their supervisors and receive a grade.\n");
        }

    }
}
