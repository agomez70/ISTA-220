﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class Personnel
    {
        public void Rank(string marineRank)
        {
            Console.WriteLine($"\tRank range: {marineRank}");
        }
        public void MOS(string jobTitle)
        {
            Console.WriteLine($"\tDifferent job titles between ranks: {jobTitle}");
        }
    }
}
