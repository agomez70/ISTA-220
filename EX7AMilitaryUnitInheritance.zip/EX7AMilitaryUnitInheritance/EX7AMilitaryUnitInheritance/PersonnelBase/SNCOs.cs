﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class SNCOs : Personnel
    {
        public void FitReps()
        {
            Console.WriteLine("\tStaff Non-Commissioned Officers get evaluated " +
                "on a yearly basis by their\n\tdirect supervisor or commander. " +
                "It is the SNCO's responsibility to write a\n\tFitness Report that " +
                "details all of their accomplishments.\n\tThis document gets reviewed " +
                "by their supervisor and receive a grade.\n\tThis Fitness Report is " +
                "equivalent to what Sergeants have to do.\n");
        }
    }
}
