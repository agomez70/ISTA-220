﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class AAV : Vehicles
    {
        public void Diving()
        {
            Console.WriteLine("\tDives in the water");
        }
        public void Danger()
        {
            Console.WriteLine("\tIt can sink");
        }
        public override void Drive()
        {
            Console.WriteLine("\tIt floats... and rides on land");
        }
    }
}
