﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class HMMWV : Vehicles
    {
        public void Accelerating()
        {
            Console.WriteLine("\tAccelerating");
        }
        public void Braking()
        {
            Console.WriteLine("\tBraking");
        }
        public override void Drive()
        {
            Console.WriteLine("\tMotoring");
        }
    }
}
