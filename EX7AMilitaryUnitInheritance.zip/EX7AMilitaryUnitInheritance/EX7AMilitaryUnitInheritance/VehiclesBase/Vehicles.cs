﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class Vehicles
    {
        public void TroopCapacity(int capacity)
        {
            Console.WriteLine($"\tThis vehicle can take up to {capacity} troops.");
        }
        public void Loudness(bool loud)
        {
            Console.WriteLine($"\tEar protection? {loud}");
        }
        public virtual void Drive()
        {
            Console.WriteLine("\tDefault");
        }

    }
}
