﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class M16 : Weapons
    {
        public void Requirement()
        {
            Console.Write("\tQualification with the M16 is mandatory yearly.\n");
        }
        public override void Size()
        {
            Console.WriteLine("\tIt only weights 6.37 lbs");
        }
    }
}
