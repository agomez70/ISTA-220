﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class M240 : Weapons
    {
        public void NonRequirement()
        {
            Console.WriteLine("\tIt is not required to qualify with the M240 yearly.");
        }
        public override void Size()
        {
            Console.WriteLine("\tIt is pretty heavy at... 27.6 lbs");
        }
    }
}
