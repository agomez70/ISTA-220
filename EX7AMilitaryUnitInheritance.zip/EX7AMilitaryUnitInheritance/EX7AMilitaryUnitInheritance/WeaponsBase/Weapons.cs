﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EX7AMilitaryUnitInheritance
{
    class Weapons 
    {
        public void AmmoType(string ammoItTakes)
        {
            Console.WriteLine($"\tThis weapon takes {ammoItTakes}");
        }
        public void Range(int projectileRange)
        {
            Console.WriteLine($"\tThis weapon's projectile will go as far as {projectileRange} feet.");
        }
        public virtual void Size()
        {
            Console.WriteLine("\tHow heavy?");
        }
    }
}
