﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class Dictionary
    {
        public static void GenericDictionary()
        {
            Menu.DictionaryMenu();
            Dictionary<string, int> ages = new Dictionary<string, int>();
            ages.Add("Andres", 22);
            ages.Add("Kaia", 22);
            ages["Juancho"] = 32;
            ages["Nick"] = 25;
            ages.Add("Naveh", 22);

            Console.WriteLine("This Dictionary contains:\n");
            foreach(KeyValuePair<string, int> element in ages)
            {
                string name = element.Key;
                int age = element.Value;
                Console.WriteLine($"Names: {name}, Age: {age} \n");
            }
        }
    }
}
