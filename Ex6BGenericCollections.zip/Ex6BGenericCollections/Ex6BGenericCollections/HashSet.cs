﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class HashSet
    {
        public static void GenericHashSet()
        {
            Menu.HashSetMenu();
            HashSet<string> classroom = new HashSet<string>(new string[]
                {"Lenore", "Rudy", "Matt", "Tyler", "Kimberly"});
            HashSet<string> experienced = new HashSet<string>(new string[]
                {"Lenore", "Rudy", "Olga", "Angel", "Donna"});

            Console.WriteLine("Individuals in the classroom: \n");
            foreach (string name in classroom)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("\n");

            Console.WriteLine("More experienced individuals: \n");
            foreach (string name in experienced)
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("\n");

            Console.WriteLine("Individuals who are experienced and in the classroom: \n");
            experienced.IntersectWith(classroom);
            foreach (string name in experienced)
            {
                Console.WriteLine(name);
            }
        }
    }
}
