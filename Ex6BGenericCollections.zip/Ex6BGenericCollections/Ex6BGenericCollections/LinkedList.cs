﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class LinkedList
    {
        public static void GenericLinkedList()
        {
            Menu.LinkedListMenu();
            LinkedList<string> names = new LinkedList<string>();
            foreach (string name in new string[] { "Andres ", "Mauricio, ", "Kaia ", "Moani, ", "Claro."})
            {
                names.AddFirst(name);
            }
            Console.Write("Iterating the names... \n\n");
            for (LinkedListNode<string> node = names.Last; node != null; node = node.Previous)
            {
                string name = node.Value;
                Console.Write(name);
            }
            Console.WriteLine("\n");
        }
    }
}
