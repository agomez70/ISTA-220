﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class List
    {
        public static void GenericList()
        {
            Menu.ListMenu();
            Console.WriteLine("List of numbers...\n");
            List<int> numbers = new List<int>();
            foreach (int number in new int[5] { 4, 25, 5, 1, 98})
            {
                numbers.Add(number);
            }
            foreach (int number in numbers)
            {
                Console.Write(number + " ");
            }
            Console.WriteLine("\n");
        }
    }
}
