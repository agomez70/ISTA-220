﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class Menu
    {
       public static void ListMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("List!\n");
            Console.WriteLine("-----");
            Console.ResetColor();
        }
        public static void LinkedListMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("LinkedList!\n");
            Console.WriteLine("-----------");
            Console.ResetColor();
        }
        public static void QueueMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Queue!\n");
            Console.WriteLine("------");
            Console.ResetColor();
        }
        public static void StackMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Stack!\n");
            Console.WriteLine("------");
            Console.ResetColor();
        }
        public static void DictionaryMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Dictionary!\n");
            Console.WriteLine("-----------");
            Console.ResetColor();
        }
        public static void SortedListMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("SortedList!\n");
            Console.WriteLine("-----------");
            Console.ResetColor();
        }
        public static void HashSetMenu()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("HashSet!\n");
            Console.WriteLine("-------");
            Console.ResetColor();
        }
    }
}
