﻿using System;

namespace Ex6BGenericCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            List.GenericList();
            LinkedList.GenericLinkedList();
            Console.ReadLine();

            Console.Clear();

            Queue.GenericQueue();
            Stack.GenericStack();
            Console.ReadLine();

            Console.Clear();

            Dictionary.GenericDictionary();
            Console.ReadLine();

            Console.Clear();

            SortedList.GenericSortedList();
            Console.ReadLine();

            Console.Clear();

            HashSet.GenericHashSet();


        }
    }
}
