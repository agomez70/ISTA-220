﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class Queue
    {
        public static void GenericQueue()
        {
            Menu.QueueMenu();
            Queue<int> years = new Queue<int>();
            Console.WriteLine("Populating the queue:\n");
            foreach (int age in new int[5] {22, 22, 3, 4, 98 })
            {
                years.Enqueue(age);
                Console.WriteLine($"{age} has joined the queue...");
            }
            Console.WriteLine("\nThe queue has these items...\n");
            foreach (int age in years)
            {
                Console.Write(age + " ");
            }
            Console.WriteLine("\n");
        }
    }
}
