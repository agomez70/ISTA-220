﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class SortedList
    {
        public static void GenericSortedList()
        {
            Menu.SortedListMenu();
            SortedList<string, int> ages = new SortedList<string, int>();
            ages.Add("Andres", 22);
            ages.Add("Kaia", 22);
            ages["Juancho"] = 32;
            ages["Nick"] = 25;
            ages.Add("Naveh", 22);

            Console.WriteLine("This sorted list contains:\n");
            foreach (KeyValuePair<string, int> element in ages)
            {
                string name = element.Key;
                int age = element.Value;
                Console.WriteLine($"Names: {name}, Age: {age} \n");
            }
        }
    }
}
