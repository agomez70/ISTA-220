﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex6BGenericCollections
{
    class Stack
    {
        public static void GenericStack()
        {
            Menu.StackMenu();
            Stack<int> years = new Stack<int>();
            Console.WriteLine("Pushing items into the stack:\n");
            foreach (int age in new int[5] { 22, 22, 3, 4, 98 })
            {
                years.Push(age);
                Console.WriteLine($"{age} has been pushed on the stack...");
            }
            Console.WriteLine("\nThe stack has these items...\n");
            foreach (int age in years)
            {
                Console.Write(age + " ");
            }
            Console.WriteLine("\n");
        }
    }
}
