﻿using System;

namespace HW5DLoopsClassesValuesReferences
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            do
            {
                i += 1;
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
            } while (i <= 11);
        }
    }
}
