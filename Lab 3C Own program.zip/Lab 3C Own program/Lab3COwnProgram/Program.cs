﻿using System;

namespace Lab3COwnProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            CollegeTuition();
            GreaterThan();
            Feet2Inches();
        }
        static void CollegeTuition()
        {
            double interest = .02d;
            double tuition = 6000d;
            for (double i = 1; i <= 5; i++)
            {
                tuition = (tuition * interest) + tuition;
                Console.WriteLine($"Tuition for year {i} is:\n{tuition}:\n\n");
            }
            
        }
        static void GreaterThan()
        {

            try
            {
                Console.WriteLine("Please enter to numbers to find the greater one");
                int a = checked(int.Parse(Console.ReadLine()));
                int b = checked(int.Parse(Console.ReadLine()));
                if (a > b)
                {
                    Console.WriteLine($"{a} greater than {b}:\n\n");
                }
                else if (a < b)
                {
                    Console.WriteLine($"{b} is greater than {a}:\n\n");
                }
                else
                    Console.WriteLine($"{a} is equal to {b}:\n\n");
            }
            catch (FormatException fEx)
            {
                Console.WriteLine($"{fEx}");
            }
        }
        static void Feet2Inches()
        {
            try
            {
                Console.WriteLine("Please insert the number of feet to be converted" +
                     " to inch.");
                double feet = checked(double.Parse(Console.ReadLine()));
                double inches = feet * 12;
                Console.WriteLine($"{feet} feet is {inches} inches.");
            }
            catch (FormatException fEx)
            {
                Console.WriteLine($"{fEx}");
            }
        }
}
}
