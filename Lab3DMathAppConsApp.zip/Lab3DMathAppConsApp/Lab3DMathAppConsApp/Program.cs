﻿using System;

namespace Lab3DMathAppConsApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu(); 
            Calculations(Operation(), numberOne(), numberTwo());
        }
        static void Menu()
        {
            Console.WriteLine("\t\t\tWelcome to the Math Calculator Application!\n");
            Console.WriteLine("\t\t\tYou will be asked to enter a math operator from " +
                "the following list: +, -, *, /\n");
            Console.WriteLine("\t\t\tOnce you enter the operator, you will be asked to enter two numbers\n" +
                "\t\t\tto find out the calculation you have desired.\n");
        }
        static char Operation()
        {
            Console.WriteLine("Please pick your poison:\n+, -, *, /\n");
            char x = char.Parse(Console.ReadLine());
            try
            {
                switch (x)
                {
                    case '+':
                        break;
                    case '-':
                        break;
                    case '*':
                        break;
                    case '/':
                        break;
                    default:
                        Console.WriteLine("Thank you for stopping by!");
                        Console.ReadKey();
                        break;
                }
                return x;
            }
            catch (FormatException fEX)
            {
                Console.WriteLine($"{fEX}");
                Console.WriteLine("Thank you for stopping by!\n");
                Console.ReadKey();
            }
            return x;
        }
        static int numberOne()
        {
            Console.WriteLine("Please enter your first number:\n");
            int a;
            try
            {
                a = checked(int.Parse(Console.ReadLine()));
                return a;
            }
            catch (FormatException)
            {
                Console.WriteLine("Please enter a valid number.\n");
                a = checked(int.Parse(Console.ReadLine()));
            }
            return a;
        }
        static int numberTwo()
        {
            Console.WriteLine("Please enter your second number:\n");
            int b;
            try
            {
                b = checked(int.Parse(Console.ReadLine()));
                return b;
            }
            catch (FormatException)
            {
                Console.WriteLine("Please enter a valid number.\n");
                b = checked(int.Parse(Console.ReadLine()));
            }
            return b;

        }
        static void Calculations(char x, int a, int b)
        {
            int result;
            try
            {
                switch (x)
                {
                    case 'x':
                        result = a + b;
                        break;
                    case '-':
                        result = a - b;
                        break;
                    case '*':
                        result = a * b;
                        break;
                    case '/':
                        result = a / b;
                        break;
                    default:
                        Console.WriteLine("Thank you for stopping by!");
                        Console.ReadKey();
                        return;
                }
                return;
            }
            catch (DivideByZeroException)
            {
                Console.WriteLine("The second number must be greater than 0 on division.\n" +
                    "Please enter a different number.");
                b = int.Parse(Console.ReadLine());
                result = a / b;
            }
            Console.WriteLine($"Your calculation resulted in {a}{x}{b} = {result}\n");
            return;
        }
    }
}