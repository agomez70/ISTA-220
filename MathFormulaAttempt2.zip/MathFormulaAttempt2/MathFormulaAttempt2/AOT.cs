﻿namespace MathFormulaAttempt2
{
    public class AOT
    {
    }
}