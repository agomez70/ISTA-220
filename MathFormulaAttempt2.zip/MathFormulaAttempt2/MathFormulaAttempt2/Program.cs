﻿using System;

namespace MathFormulaAttempt2
{
    class Program
    {
        private static double p1;

        static void Main(string[] args)
        {
            // This will call the circumference of the circle 
            Console.WriteLine("\t\tEnter the radius of your circle to find the circumference: \n");
            double radius = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"\nSince the radius of your circle is {radius}.\n\nThe circumference equals to: " +
                $"{GetCircumference(radius)} ");

            Console.WriteLine("Press Enter to Continue..."); Console.ReadLine();

            // This will call the area of the circle 
            Console.WriteLine("\t\tEnter the radius of your circle to find the area: \n");
            double radius1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"\tSince the radius of your circle is {radius}.\n\nThe area equals to: " +
                $"{GetArea(radius)} ");

            Console.WriteLine("Press Enter to Continue..."); Console.ReadLine();

            // This will call the volume of the hemisphere 
            Console.WriteLine("\t\tEnter the radius of your circle to find the volume of the hemisphere: \n");
            double radius2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"\tSince the radius of your circle is {radius2}.\n\nThe volume of the hemisphere equals to: " +
                $"{GetVolHemis(radius2)} ");

            Console.WriteLine("Press Enter to Continue..."); Console.ReadLine();

            // This will call the area of the triangle 
            Console.WriteLine("\t\tEnter the three sides of your triangle to find the area: \n");
            float a = float.Parse(Console.ReadLine());
            float b = float.Parse(Console.ReadLine());
            float c = float.Parse(Console.ReadLine());
            Console.WriteLine($"Area of Triangle: {GetAT(float a, float b, float c)}");

            Console.WriteLine("Press Enter to Continue..."); Console.ReadLine();

            // This will call the quadratic formula 
            Console.WriteLine("Please enter three values to solve the quadratic formula");
            float a1 = float.Parse(Console.ReadLine());
            float b1 = float.Parse(Console.ReadLine());
            float c1 = float.Parse(Console.ReadLine());
            QuaFor(a1, b1, c1);
            Console.WriteLine($"The result of this quadratic formula with th given numbers: {a}, {b}, {c}");
        }
        public static double GetCircumference(double radius)
        {
            return 2 * Math.PI * radius;
        }
        public static double GetArea(double radius1)
        {
            return Math.PI * (radius1 * radius1);
        }
        public static double GetVolHemis(double radius2)
        {      
            double result = (4 / 3) * Math.PI * (radius2 * radius2 * radius2);
            return result / 2;
        }
            
        public static double GetAT(float a, float b, float c)
        {
            float a = float.Parse(Console.ReadLine());
            float b = float.Parse(Console.ReadLine());
            float c = float.Parse(Console.ReadLine());
            float p = a + b + c;
            float s = p / 2;
            return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
        }
        public static void QuaFor(float a1, float b1, float c1)
        {

            double insideSqrt = Math.Sqrt((b1 * b1) - 4 * a1 * c1);

            if (insideSqrt > 0)
            {
                double x1 = (-b1 + insideSqrt) / 2;
                double x2 = (-b1 - insideSqrt) / 2;
                Console.WriteLine($"The result of this quadratic formula with the given numbers is {x1} and {x2}.");
            }
            else
            {
                Console.WriteLine("This equation has no solution.");
            }
        }
    }
}


// cannot figure out how to make AOT to work but i got the quadratic!