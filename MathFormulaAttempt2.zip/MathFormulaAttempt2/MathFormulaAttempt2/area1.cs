﻿namespace MathFormulaAttempt2
{
    public class area1
    {
    }
}