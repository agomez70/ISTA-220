﻿using System;

namespace MathFormulas
{
    class Program
    {
        static void Main(string[] args)
        {
            // Part 1: Area and Circumference of a circle given the radius of a circle
            Console.WriteLine("\t\tEnter the radius of your circle to find the area and the circumference:\n");
            double radius = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();
            double pi = Math.PI;

            double cir = 2 * pi * radius;
            double area = pi * (radius * radius);

            Console.WriteLine($"Since the radius of your circle is {radius}.\nThe Circumference equals to: {cir}\n" +
                $"The Area equals to: {area}\n");

            Console.WriteLine("Press Enter to Continue..."); Console.ReadLine();

            // Part 2: Calculate the volume of a hemisphere given the length of a radius

            Console.WriteLine("\t\tPlease enter the radius of your hemisphere to find the volume.\n");
            double radius1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();

            double result = 4 / 3 * pi * (radius1 * radius1 * radius1);
            double volume = result / 2;

            Console.WriteLine($"Given the radius of {radius1} that you have given,\nthe volume of the hemisphere is {volume}\n\n");

            Console.WriteLine("Press Enter again to Continue...\n"); Console.ReadLine();

            // Part 3: Area of a triangle given the length of the sides 
            Console.WriteLine("\t\tNow we will look at the area of a triangle.\n");
            Console.WriteLine("Please enter the length of each side of your triangle:\n");

            Console.WriteLine("First side: ");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Second side: ");
            double b = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Third side: ");
            double c = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine();


            double p = a + b + c;
            double p1 = (a + b + c) / 2;

            double areaT = Math.Sqrt(p1 * (p1 - a) * (p1 - b) * (p1 - c));

            Console.WriteLine($"Given the three sides of your tringle entered as {a}, {b}, {c},\n" +
                $"we found the perimeter which was {p}.\n" +
                $"We then found the semi-perimeter which resulted in {p1}.\n" +
                $"Then we found the area of the triangle by using the rest of Heron's Formula.\n" +
                $"Ultimately, the area of your triangle is {areaT}\n");

            // Part 4: Write a program that solves the quadratic formula
            Console.WriteLine("Press Enter one last time to Continue...");
            Console.ReadLine();

            Console.WriteLine("\t\tLastly, we will do the quadratic formula\n");
            Console.WriteLine("Please enter the values you would like use for this formula below:");

            Console.WriteLine("The value of the first number will always be '1' in order to find the square root.");
            float a1 = 1; Console.WriteLine($"{a1}");
            Console.WriteLine("What is your second number?");
            float b1 = float.Parse(Console.ReadLine());
            Console.WriteLine("What is your third number?");
            float c1 = float.Parse(Console.ReadLine());

            QuaFor(a1, b1, c1);
        }

        public static void QuaFor(float a1, float b1, float c1)
        {
            double insideSqrt = Math.Sqrt((b1 * b1) - 4 * a1 * c1);

            if (insideSqrt > 0)
            {
                double x1 = (-b1 + insideSqrt) / 2;
                double x2 = (-b1 - insideSqrt) / 2;
                Console.WriteLine($"The result of this quadratic formula with the given numbers: {a1}, {b1}, {c1},\n" +
                $"has resulted in {x1} and {x2}");
            }
            else
            {
                Console.WriteLine("This equation has no solution.");
            }
        }   
    }   
}
