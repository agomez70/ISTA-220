﻿namespace MathFormulas
{
    internal class circumference
    {
    }
}