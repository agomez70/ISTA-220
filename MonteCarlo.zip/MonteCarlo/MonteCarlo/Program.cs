﻿using System;
using System.Collections;

namespace MonteCarlo
{
    class Program  
    {
        static void Main(string[] args)
        {
            Console.WriteLine("How many times do you want to iterate?");
            int iterations = int.Parse(Console.ReadLine());
            
            for (int x = 0; x < iterations; x++)
            {
                randomHypoT();
                randomHypoT1();
                hypotenuse();
                int result1 = hypotenuse();
                   if (hypotenuse() > 1)
                   {
                        int counter = 0;
                        result1 = counter++;
                        int division = counter / iterations;
                        int result = division * 4;
                        Console.WriteLine($"This is the result: {result}");
                        // this statement will not print to screen :(
                   }
                   else { }
            }
            double abs = Math.Abs(Math.PI);
            Console.WriteLine($"The absolute value of PI: {abs}");   
        }
        static float randomHypoT()
        {
            Random r = new Random();
            float x = (float)r.NextDouble();
            return x;
        }
        static float randomHypoT1()
        { 
            Random r = new Random();
            float y = (float)r.NextDouble();
            return y;
        }
        static int hypotenuse()
        {
            float x = randomHypoT();
            float y = randomHypoT1();
            float hypoT = (float)Math.Sqrt((x * x) + (y * y));
            return (int)hypoT;
        }
    }
}
