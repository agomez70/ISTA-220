﻿using System;

namespace MyFarmApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Welcome();
            FirstAnimal();
            SecondAnimal();
            ThirdAnimal();
            FourthAnimal();
            FifthAnimal();
            Goodbye();

        }
        public static void Welcome()
        {
            Console.WriteLine("\t\t\t\tWELCOME TO MAO'S FARM!\n\n");
        }
        public static void FirstAnimal()
        {
            Bull bull = new Bull();
            bull.Name(); bull.Speak(); bull.Size(); bull.Attitude();
            Console.WriteLine($"My name is {bull.AnimalName} the bull." +
                $" I usually make {bull.AnimalSpeak}. I am about {bull.HowBig}" +
                $" feet tall! Also, I am usually {bull.Mood}.\n");
        }
        public static void SecondAnimal()
        {
            Horse horse = new Horse();
            horse.Name(); horse.Speak(); horse.Size(); horse.Attitude();
            Console.WriteLine($"My name is {horse.AnimalName} the horse." +
                $" I usually say {horse.AnimalSpeak}. I am about {horse.HowBig}" +
                $" feet tall! Also, I am usually just {horse.Mood}.\n");
        }
        public static void ThirdAnimal()
        {
            Cow cow = new Cow();
            cow.Name(); cow.Speak(); cow.Size(); cow.Attitude();
            Console.WriteLine($"My name is {cow.AnimalName} the cow." +
                $" I usually say {cow.AnimalSpeak} really loud!. I am about {cow.HowBig}" +
                $" feet tall! Also, I am usually very {cow.Mood}.\n");
        }
        public static void FourthAnimal()
        {
            Chicken chicken = new Chicken();
            chicken.Name(); chicken.Speak(); chicken.Size(); chicken.Attitude();
            Console.WriteLine($"My name is {chicken.AnimalName} the chicken." +
                $" I usually say {chicken.AnimalSpeak}. I am about {chicken.HowBig}" +
                $" feet tall! Also, I am usually so so so darn {chicken.Mood}!\n");
        }
        public static void FifthAnimal()
        {
            Sheep sheep = new Sheep();
            sheep.Name(); sheep.Speak(); sheep.Size(); sheep.Attitude();
            Console.WriteLine($"My name is {sheep.AnimalName} the sheep!!" +
                $" I usually say {sheep.AnimalSpeak} really loud! I am about {sheep.HowBig}" +
                $" feet tall! Andddd, I am usually just {sheep.Mood}.\n");
        }
        public static void Goodbye()
        {
            Console.WriteLine("\t\t\t\tTHAT'S IT FOLKS! HAVE A GOOD DAY!!");
        }


    }
}

