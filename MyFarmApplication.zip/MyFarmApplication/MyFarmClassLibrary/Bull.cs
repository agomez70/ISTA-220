﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarmApplication
{
    public class Bull
    {

        public string AnimalName { get; set; }
        public string AnimalSpeak { get; set; }
        public double HowBig { get; set; }
        public string Mood { get; set; }


        public void Name()
        {
            this.AnimalName = "Bill";
        }
        public void Speak()
        {
            this.AnimalSpeak = "angry moo sounds.";
        }
        public void Size()
        {
            this.HowBig = 5.8;
        }
        public void Attitude()
        {
            this.Mood = "furious";
        }

    }
}
