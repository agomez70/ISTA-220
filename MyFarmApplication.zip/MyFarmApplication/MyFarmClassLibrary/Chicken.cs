﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarmApplication
{
    public class Chicken
    {
        public string AnimalName { get; set; }
        public string AnimalSpeak { get; set; }
        public double HowBig { get; set; }
        public string Mood { get; set; }


        public void Name()
        {
            this.AnimalName = "Charles";
        }
        public void Speak()
        {
            this.AnimalSpeak = "buck-buck-buck";
        }
        public void Size()
        {
            this.HowBig = 2.3;
        }
        public void Attitude()
        {
            this.Mood = "confused";
        }
    }

}
