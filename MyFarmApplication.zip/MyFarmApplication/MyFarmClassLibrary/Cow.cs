﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarmApplication
{
    public class Cow
    {
        public string AnimalName { get; set; }
        public string AnimalSpeak { get; set; }
        public double HowBig { get; set; }
        public string Mood { get; set; }


        public void Name()
        {
            this.AnimalName = "Coby";
        }
        public void Speak()
        {
            this.AnimalSpeak = "moooooo";
        }
        public void Size()
        {
            this.HowBig = 5.3;
        }
        public void Attitude()
        {
            this.Mood = "hungry";
        }

    }
}
