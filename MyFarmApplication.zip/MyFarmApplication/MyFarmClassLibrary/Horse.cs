﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarmApplication
{
    public class Horse
    {
        public string AnimalName { get; set; }
        public string AnimalSpeak { get; set; }
        public double HowBig { get; set; }
        public string Mood { get; set; }


        public void Name()
        {
            this.AnimalName = "Holt";
        }
        public void Speak()
        {
            this.AnimalSpeak = "neeeeiggghhh";
        }
        public void Size()
        {
            this.HowBig = 6.3;
        }
        public void Attitude()
        {
            this.Mood = "relaxing";
        }
    }
}
