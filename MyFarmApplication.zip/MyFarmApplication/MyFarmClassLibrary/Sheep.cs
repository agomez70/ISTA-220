﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyFarmApplication
{
    public class Sheep
    {
        public string AnimalName { get; set; }
        public string AnimalSpeak { get; set; }
        public double HowBig { get; set; }
        public string Mood { get; set; }


        public void Name()
        {
            this.AnimalName = "Samantha";
        }
        public void Speak()
        {
            this.AnimalSpeak = "bebebbebebee";
        }
        public void Size()
        {
            this.HowBig = 3.9;
        }
        public void Attitude()
        {
            this.Mood = "lost..";
        }
    }
}
