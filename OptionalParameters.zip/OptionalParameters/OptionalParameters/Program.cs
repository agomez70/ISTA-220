﻿using System;

namespace OptionalParameters
{
    class Program
    {
        // In my opinion, Syntatic Sugar the concept of making your 
        // code reading and maintainable. Being able to not struggle
        // as your reading someone elses code. It makes the code 
        // "sweeter" for other developers and yourself to read.

        static void Main(string[] args)
        {
            
            Add(5); // 5 + 10; prints: answer: 15
            Add(10); // 10 + 10; 1st: x, 2nd: default
                    // prints: answer: 20 // named arguments
            Add(y: 12, x: 22); // 12 + 22; // named arg out of order.
                                          // answer: 34
        }
        public static void Add(int x, int y = 10) // y is optional 
                                                 // bc they have default values
        {
            int answer = x + y;
            Console.WriteLine($"Answer: {answer}");
        }
            
            void Add1(int x, int y = 10)
            {
                int result = x + y;
                Console.WriteLine($"The {x} added to {y}: {result}");

                Add1(x);
                Add1(x + y);

            }
        
    }
}
