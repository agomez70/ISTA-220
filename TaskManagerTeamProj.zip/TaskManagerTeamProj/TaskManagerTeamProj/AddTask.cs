﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TaskManagerTeamProj
{
    class AddTask
    {
        public static void Prints()
        {
            Console.WriteLine("\t\t\tAdd Tasks To List\n\n");
            Console.WriteLine("Enter the name of the task you would like add:");
        }
        public static string AddTasks()
        {
            string task = Console.ReadLine();
            Console.WriteLine("");
            return task;
        }
        public static string AddDescription()
        {
            Console.WriteLine("Enter a description:");
            string description = Console.ReadLine();
            return description;
        }
        //TODO: Add created task to the display list 
    }
}
