﻿using System;

namespace TaskManagerTeamProj
{
    class Program
    {
        static void Main(string[] args)
        {
            AddTask.Prints();
            Console.WriteLine($"Task: {AddTask.AddTasks()}. Description: {AddTask.AddDescription()} ");
        }
    }
}
